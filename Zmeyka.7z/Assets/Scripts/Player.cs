﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour

{
    // скорость перемещения - 6 единиц в секунду по умолчанию
    // в редакторе можно поменять
    public float speed = 1;
    private bool _testing = false;
    
    public GameObject SnakeBody;
    public List<GameObject> BodySnake = new List<GameObject> { };

    // аналогично скорость вращения 60 градусов в секунду по умолчанию
    public float rotationSpeed = 60;

    // локальная переменная для хранения ссылки на компонент CharacterController
    private CharacterController _controller;
    public void AddTile() {
        Vector3 Position = transform.position;
        if (BodySnake.Count > 0) {
            Position = BodySnake[BodySnake.Count - 1].transform.position;
        }
        Position.y+=10f;
        GameObject Body = Instantiate(SnakeBody, Position, Quaternion.identity) as GameObject;
        BodySnake.Add(Body);
    }

    public void Start()
    {
        BodySnake.Clear();
        for (int i = 0; i < 5; i++) AddTile();
        _controller = GetComponent<CharacterController>();
        }


    public void Update()
    {
         SnakeStap();
        /* 
         * Гибкий способ - использовать оси
         * Unity имеет набор предустоновленных осей, которые можно использовать
         * следующий код будет работать как на клавиатуре (стрелки и WSAD), так и на геймпаде
         */

        // получаем значение вертикальной оси ввода
        /* float vertical = Input.GetAxis("Vertical"); */

        // получаем значение горизонтальной оси ввода
        float horizontal = Input.GetAxis("Horizontal");

        // вращаем трансформ вокруг оси Y 
        transform.Rotate(rotationSpeed * Time.deltaTime * horizontal,0, 0);
        
        // двигаем змею постоянно
        _testing = true; // маленкий хинт, для того, чтобы не обрабатывать несколько коллизий за кадр
        _controller.Move(transform.forward * speed * Time.deltaTime /* * vertical*/);

        // получаем компонент CharacterController и 
        // записываем его в локальную переменную   

    }
    void SnakeStap() {
        if (BodySnake.Count > 0)
        {
            BodySnake[0].transform.position = transform.position;
            for (int BodyIndex = BodySnake.Count - 1; BodyIndex > 0; BodyIndex--)
                BodySnake[BodyIndex].transform.position = BodySnake[BodyIndex - 1].transform.position;
        }
    }
    public void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (_testing)
        {
            Food food = hit.collider.GetComponent<Food>();
            if (food != null)
            {
                // врезались в еду, "съедаем" ее
                food.Eat();
                AddTile();
            }
            else
            {
                // врезались не в еду
                SceneManager.LoadScene ("GameOver");
            }
            _testing = false;
        }
    }

}

